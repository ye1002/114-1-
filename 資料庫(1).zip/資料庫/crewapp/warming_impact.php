<?php
include('db_config.php');

if (isset($_POST['add_warming'])) {
    $area = $conn->real_escape_string($_POST['sea_area']);
    $temp = (float)$_POST['avg_temp_increase'];
    $bleach = (int)$_POST['coral_bleaching_rate'];
    $impact = ($temp > 1.5 || $bleach > 50) ? "生態危機" : "持續觀察";
    $conn->query("INSERT INTO warming_impact (sea_area, avg_temp_increase, coral_bleaching_rate, impact_level) VALUES ('$area', $temp, $bleach, '$impact')");
}

if (isset($_POST['delete_selected']) && !empty($_POST['delete_ids'])) {
    $ids = implode(',', array_map('intval', $_POST['delete_ids']));
    $conn->query("DELETE FROM warming_impact WHERE id IN ($ids)");
}

$result = $conn->query("SELECT * FROM warming_impact ORDER BY avg_temp_increase DESC");
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>全球暖化影響分析</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Noto Sans TC'; background-color: #f4f6f9; }
        .navbar { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
    </style>
</head>

<body>

<nav class="navbar navbar-dark sticky-top shadow mb-4">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fa-solid fa-water me-2"></i> 台灣水域環境平台
        </a>
        <span class="navbar-text text-white d-none d-md-inline">
            <i class="fa-solid fa-calendar-day me-1"></i> <?php echo date("Y-m-d"); ?>
        </span>
    </div>
</nav>

<div class="container-fluid mt-4">
    <div class="row">
        <?php include('sidebar.php'); ?>
        <div class="col-lg-9">
            <div class="card p-4 shadow-sm mb-4 border-start border-danger border-5">
                <h4 class="text-danger mb-4"><i class="fa-solid fa-temperature-arrow-up me-2"></i>全球暖化與海洋生態影響</h4>
                <form method="POST" class="row g-3">
                    <div class="col-md-4"><input type="text" name="sea_area" class="form-control" placeholder="海域(如: 墾丁、綠島)" required></div>
                    <div class="col-md-3"><input type="number" step="0.1" name="avg_temp_increase" class="form-control" placeholder="平均升溫(°C)" required></div>
                    <div class="col-md-3"><input type="number" name="coral_bleaching_rate" class="form-control" placeholder="珊瑚白化率(%)" required></div>
                    <div class="col-md-2"><button type="submit" name="add_warming" class="btn btn-danger w-100">提交分析</button></div>
                </form>
            </div>
            <div class="card p-0 shadow-sm border-0">
                <form method="POST">
                <div class="p-3 d-flex justify-content-between"><h5>生態監測報告表</h5><button name="delete_selected" class="btn btn-sm btn-outline-dark">批次刪除</button></div>
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-warning text-dark"><tr><th>#</th><th>觀測海域</th><th>平均升溫</th><th>珊瑚白化率</th><th>生態現況</th></tr></thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><input type="checkbox" name="delete_ids[]" value="<?= $row['id'] ?>"></td>
                            <td class="fw-bold"><?= $row['sea_area'] ?></td>
                            <td><i class="fa-solid fa-thermometer-half text-danger me-1"></i>+<?= $row['avg_temp_increase'] ?> °C</td>
                            <td>
                                <div class="progress" style="height: 10px;">
                                    <div class="progress-bar bg-danger" style="width: <?= $row['coral_bleaching_rate'] ?>%"></div>
                                </div>
                                <small><?= $row['coral_bleaching_rate'] ?>%</small>
                            </td>
                            <td><span class="badge <?= ($row['impact_level']=='生態危機')?'bg-danger':'bg-success' ?>"><?= $row['impact_level'] ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                </form>
            </div>

            <footer class="mt-4 pb-4 text-center text-muted small">
                © 2026 台灣水域環境平台專案 - 海綿寶寶與派大星開發
            </footer>

        </div>
    </div>
</div>
</body>
</html>