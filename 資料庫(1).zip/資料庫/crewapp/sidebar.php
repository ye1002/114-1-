<div class="col-lg-3 mb-4">
    <div class="card p-3 bg-dark text-white shadow" style="min-height: 80vh; position: sticky; top: 20px;">
        <h5 class="mb-4 border-bottom pb-2 text-info">
            <i class="fa-solid fa-compass me-2"></i>功能選單
        </h5>
        <ul class="nav flex-column font-weight-bold">
            <li class="nav-item mb-2">
                <a href="coastal_retreat.php" class="nav-link text-white <?php echo (basename($_SERVER['PHP_SELF']) == 'coastal_retreat.php') ? 'bg-primary rounded' : ''; ?>">
                    <i class="fa-solid fa-chart-line me-2 text-warning"></i> 1. 海岸線退縮分析
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="warming_impact.php" class="nav-link text-white <?php echo (basename($_SERVER['PHP_SELF']) == 'warming_impact.php') ? 'bg-primary rounded' : ''; ?>">
                    <i class="fa-solid fa-temperature-high me-2 text-danger"></i> 2. 暖化生態影響
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="beach_safety.php" class="nav-link text-white <?php echo (basename($_SERVER['PHP_SELF']) == 'beach_safety.php') ? 'bg-primary rounded' : ''; ?>">
                    <i class="fa-solid fa-shield-halved me-2 text-info"></i> 3. 海水浴場安全
                </a>
            </li>
            <li class="nav-item mb-2">
                <a href="marine_debris.php" class="nav-link text-white <?php echo (basename($_SERVER['PHP_SELF']) == 'marine_debris.php') ? 'bg-primary rounded' : ''; ?>">
                    <i class="fa-solid fa-trash-can me-2 text-success"></i> 4. 海洋垃圾危害
                </a>
            </li>
        </ul>
    </div>
</div>