<?php
// 1. 引入資料庫連線
include('db_config.php');

// 2. 處理新增邏輯
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_debris'])) {
    $location = $conn->real_escape_string($_POST['location']);
    $type = $_POST['debris_type'];
    $weight = (float)$_POST['weight_kg'];
    
    // 自定義危害演算法：根據垃圾種類給予權重
    $weight_factor = 1.0;
    switch($type) {
        case '廢棄漁網': $weight_factor = 2.5; break;
        case '塑膠微粒': $weight_factor = 2.0; break;
        case '保麗龍': $weight_factor = 1.8; break;
        case '塑膠瓶罐': $weight_factor = 1.2; break;
        default: $weight_factor = 1.0;
    }
    
    // 計算分數並限制在 0-100 之間
    $impact_score = min(100, round(($weight * $weight_factor) * 5)); 

    $sql_insert = "INSERT INTO marine_debris (location, debris_type, weight_kg, eco_impact_score) 
                   VALUES ('$location', '$type', $weight, $impact_score)";
    
    if ($conn->query($sql_insert)) {
        header("Location: marine_debris.php?status=added");
        exit();
    }
}

// 3. 處理批次刪除邏輯
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_selected'])) {
    if (!empty($_POST['delete_ids'])) {
        $ids_to_delete = implode(',', array_map('intval', $_POST['delete_ids']));
        $sql_delete = "DELETE FROM marine_debris WHERE id IN ($ids_to_delete)";
        $conn->query($sql_delete);
        header("Location: marine_debris.php?status=deleted");
        exit();
    }
}

// 4. 取得所有紀錄
$result = $conn->query("SELECT * FROM marine_debris ORDER BY analysis_date DESC");
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>海洋垃圾危害分析 - 台灣水域環境平台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        body { font-family: 'Noto Sans TC', sans-serif; background-color: #f0f4f8; }
        .navbar { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .progress { height: 12px; border-radius: 6px; background-color: #e9ecef; }
        .table-hover tbody tr:hover { background-color: #f8f9fa; }
        .impact-high { color: #dc3545; font-weight: bold; }
        .impact-mid { color: #fd7e14; font-weight: bold; }
        .impact-low { color: #20c997; font-weight: bold; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark sticky-top shadow mb-4">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fa-solid fa-water me-2"></i> 台灣水域環境平台
        </a>
        <span class="navbar-text text-white d-none d-md-inline">
            <i class="fa-solid fa-calendar-day me-1"></i> <?php echo date("Y-m-d"); ?>
        </span>
    </div>
</nav>

<div class="container-fluid px-4">
    <div class="row">
        
        <?php include('sidebar.php'); ?>

        <div class="col-lg-9">
            
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold text-dark mb-4">
                        <i class="fa-solid fa-file-medical me-2 text-danger"></i>新增海洋垃圾觀測紀錄
                    </h5>
                    <form action="" method="POST" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label small">觀測地點</label>
                            <input type="text" name="location" class="form-control" placeholder="如：八斗子漁港" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small">主要垃圾種類</label>
                            <select name="debris_type" class="form-select">
                                <option value="塑膠瓶罐">塑膠瓶罐</option>
                                <option value="廢棄漁網">廢棄漁網 (高危害)</option>
                                <option value="保麗龍">保麗龍</option>
                                <option value="塑膠微粒">塑膠微粒 (極高危害)</option>
                                <option value="一般垃圾">一般垃圾</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small">總重量 (kg)</label>
                            <input type="number" step="0.01" name="weight_kg" class="form-control" placeholder="10.5" required>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" name="add_debris" class="btn btn-dark w-100 fw-bold">
                                <i class="fa-solid fa-calculator me-1"></i> 進行危害分析
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body p-0">
                    <form method="post" onsubmit="return confirm('確定要刪除選中的紀錄嗎？');">
                        <div class="d-flex justify-content-between align-items-center p-4">
                            <h5 class="fw-bold m-0 text-dark">
                                <i class="fa-solid fa-chart-pie me-2 text-success"></i>海洋垃圾影響紀錄清單
                            </h5>
                            <button type="submit" name="delete_selected" class="btn btn-outline-danger btn-sm px-3">
                                <i class="fa-solid fa-trash-can me-1"></i> 批次移除
                            </button>
                        </div>

                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4" width="40">
                                            <input type="checkbox" class="form-check-input" onclick="toggleAll(this)">
                                        </th>
                                        <th>發現地點</th>
                                        <th>種類</th>
                                        <th>重量 (kg)</th>
                                        <th width="25%">生態危害指數</th>
                                        <th>記錄時間</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($result->num_rows > 0): ?>
                                        <?php while($row = $result->fetch_assoc()): 
                                            $score = $row['eco_impact_score'];
                                            // 判斷顏色
                                            $bar_class = "bg-success";
                                            $text_class = "impact-low";
                                            if($score >= 70) { $bar_class = "bg-danger"; $text_class = "impact-high"; }
                                            elseif($score >= 40) { $bar_class = "bg-warning"; $text_class = "impact-mid"; }
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <input type="checkbox" name="delete_ids[]" value="<?php echo $row['id']; ?>" class="form-check-input">
                                            </td>
                                            <td class="fw-bold"><?php echo htmlspecialchars($row['location']); ?></td>
                                            <td>
                                                <span class="badge bg-light text-dark border">
                                                    <?php echo $row['debris_type']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo number_format($row['weight_kg'], 2); ?> kg</td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="progress flex-grow-1 me-2">
                                                        <div class="progress-bar <?php echo $bar_class; ?>" 
                                                             role="progressbar" 
                                                             style="width: <?php echo $score; ?>%"></div>
                                                    </div>
                                                    <span class="<?php echo $text_class; ?>"><?php echo $score; ?></span>
                                                </div>
                                            </td>
                                            <td class="small text-muted">
                                                <?php echo date('Y-m-d H:i', strtotime($row['analysis_date'])); ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-5 text-muted">
                                                <i class="fa-solid fa-folder-open d-block mb-2 fs-3"></i>
                                                尚無海洋垃圾紀錄
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
            </div>
            <footer class="mt-4 pb-4 text-center text-muted small">
                © 2026 台灣水域環境平台專案 - 海綿寶寶與派大星開發
            </footer>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function toggleAll(source) {
        const checkboxes = document.getElementsByName('delete_ids[]');
        for(let i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = source.checked;
        }
    }
</script>

</body>
</html>