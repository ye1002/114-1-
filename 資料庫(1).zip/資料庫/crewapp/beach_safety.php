<?php
// 1. 引入資料庫連線設定
include('db_config.php');

// 2. 處理刪除邏輯 (批次刪除)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_selected'])) {
    if (!empty($_POST['delete_ids'])) {
        $ids_to_delete = implode(',', array_map('intval', $_POST['delete_ids']));
        $sql_delete = "DELETE FROM beach_safety WHERE id IN ($ids_to_delete)";
        if ($conn->query($sql_delete)) {
            $msg = "成功刪除 " . count($_POST['delete_ids']) . " 筆資料";
            $msg_type = "success";
        }
    } else {
        $msg = "請先勾選要刪除的項目";
        $msg_type = "warning";
    }
}

// 3. 處理新增邏輯
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_data'])) {
    $beach_name = $conn->real_escape_string($_POST['beach_name']);
    $rip_current = (int)$_POST['rip_current_risk'];
    $wave_height = (float)$_POST['wave_height_avg'];
    
    // 自動判斷安全狀態邏輯
    if ($wave_height > 2.0 || $rip_current > 7) {
        $status = "危險 (停止活動)";
    } elseif ($wave_height > 1.0 || $rip_current > 4) {
        $status = "警戒 (注意安全)";
    } else {
        $status = "安全 (適合活動)";
    }

    $sql_insert = "INSERT INTO beach_safety (beach_name, rip_current_risk, wave_height_avg, safety_status) 
                   VALUES ('$beach_name', $rip_current, $wave_height, '$status')";
    if ($conn->query($sql_insert)) {
        $msg = "數據新增成功！";
        $msg_type = "success";
    }
}

// 4. 取得最新數據
$result = $conn->query("SELECT * FROM beach_safety ORDER BY last_updated DESC");
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>海水浴場安全分析 - 台灣水域環境平台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        body { font-family: 'Noto Sans TC', sans-serif; background-color: #f8f9fa; }
        .navbar { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .table thead { background-color: #f1f3f5; }
        .status-badge { font-size: 0.9rem; padding: 6px 12px; border-radius: 20px; }
        .sidebar-link.active { background-color: #0d6efd !important; color: white !important; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark sticky-top shadow mb-4">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fa-solid fa-water me-2"></i> 台灣水域環境平台
        </a>
        <span class="navbar-text text-white d-none d-md-inline">
            <i class="fa-solid fa-calendar-day me-1"></i> <?php echo date("Y-m-d"); ?>
        </span>
    </div>
</nav>

<div class="container-fluid px-4">
    <div class="row">
        
        <?php include('sidebar.php'); ?>

        <div class="col-lg-9">
            
            <?php if(isset($msg)): ?>
            <div class="alert alert-<?php echo $msg_type; ?> alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-circle-info me-2"></i> <?php echo $msg; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="card mb-4 mt-2">
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold mb-4 text-primary">
                        <i class="fa-solid fa-square-plus me-2"></i>新增觀測數據
                    </h5>
                    <form action="" method="POST" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">海水浴場名稱</label>
                            <input type="text" name="beach_name" class="form-control" placeholder="例如：墾丁南灣" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">平均浪高 (m)</label>
                            <input type="number" step="0.1" name="wave_height_avg" class="form-control" placeholder="0.5" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">離岸流風險 (1-10)</label>
                            <select name="rip_current_risk" class="form-select">
                                <?php for($i=1; $i<=10; $i++) echo "<option value='$i'>$i 級</option>"; ?>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" name="add_data" class="btn btn-primary w-100 fw-bold">
                                <i class="fa-solid fa-magnifying-glass-chart me-1"></i> 分析
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body p-0">
                    <form method="post" onsubmit="return confirm('確定要刪除選中的數據嗎？');">
                        <div class="d-flex justify-content-between align-items-center p-4">
                            <h5 class="fw-bold m-0 text-secondary">
                                <i class="fa-solid fa-table-list me-2"></i>即時監測與分析紀錄
                            </h5>
                            <button type="submit" name="delete_selected" class="btn btn-outline-danger btn-sm px-3">
                                <i class="fa-solid fa-trash-can me-1"></i> 刪除選中項目
                            </button>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light text-secondary">
                                    <tr>
                                        <th class="ps-4" width="40">
                                            <input type="checkbox" class="form-check-input" onclick="toggleAll(this)">
                                        </th>
                                        <th>海水浴場</th>
                                        <th>平均浪高</th>
                                        <th>離岸流</th>
                                        <th>安全評估結果</th>
                                        <th>最後觀測時間</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($result->num_rows > 0): ?>
                                        <?php while($row = $result->fetch_assoc()): 
                                            // 判斷 Badge 顏色
                                            $badge_color = "text-bg-success";
                                            if(strpos($row['safety_status'], '危險') !== false) $badge_color = "text-bg-danger";
                                            elseif(strpos($row['safety_status'], '警戒') !== false) $badge_color = "text-bg-warning";
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <input type="checkbox" name="delete_ids[]" value="<?php echo $row['id']; ?>" class="form-check-input">
                                            </td>
                                            <td class="fw-bold text-dark"><?php echo htmlspecialchars($row['beach_name']); ?></td>
                                            <td><i class="fa-solid fa-wave-square text-info me-1"></i> <?php echo $row['wave_height_avg']; ?> m</td>
                                            <td><i class="fa-solid fa-triangle-exclamation text-muted me-1"></i> <?php echo $row['rip_current_risk']; ?> / 10</td>
                                            <td>
                                                <span class="badge rounded-pill <?php echo $badge_color; ?> status-badge">
                                                    <?php echo $row['safety_status']; ?>
                                                </span>
                                            </td>
                                            <td class="small text-muted">
                                                <?php echo date('Y/m/d H:i', strtotime($row['last_updated'])); ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-5 text-muted">目前尚無監測數據</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
            </div>
            
            <footer class="mt-4 pb-4 text-center text-muted small">
                © 2026 台灣水域環境平台專案 - 海綿寶寶與派大星開發
            </footer>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // 全選/全不選功能
    function toggleAll(source) {
        const checkboxes = document.getElementsByName('delete_ids[]');
        for(let i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = source.checked;
        }
    }
</script>

</body>
</html>