<?php
include('db_config.php');

if (isset($_POST['add_retreat'])) {
    $region = $conn->real_escape_string($_POST['region_name']);
    $year = (int)$_POST['observation_year'];
    $dist = (float)$_POST['retreat_distance'];
    $risk = ($dist > 5) ? "極高危險" : (($dist > 2) ? "中度警戒" : "穩定");
    $conn->query("INSERT INTO coastal_retreat (region_name, observation_year, retreat_distance, risk_level) VALUES ('$region', $year, $dist, '$risk')");
}

if (isset($_POST['delete_selected']) && !empty($_POST['delete_ids'])) {
    $ids = implode(',', array_map('intval', $_POST['delete_ids']));
    $conn->query("DELETE FROM coastal_retreat WHERE id IN ($ids)");
}

$result = $conn->query("SELECT * FROM coastal_retreat ORDER BY observation_year DESC");
?>

<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>海岸線退縮分析</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Noto Sans TC'; background-color: #ffffffff; }
        .navbar { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
    </style>
</head>

<body>

<nav class="navbar navbar-dark sticky-top shadow mb-4">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fa-solid fa-water me-2"></i> 台灣水域環境平台
        </a>
        <span class="navbar-text text-white d-none d-md-inline">
            <i class="fa-solid fa-calendar-day me-1"></i> <?php echo date("Y-m-d"); ?>
        </span>
    </div>
</nav>

<div class="container-fluid mt-4">
    <div class="row">
        <?php include('sidebar.php'); ?>
        <div class="col-lg-9">
            <div class="card p-4 shadow-sm mb-4 border-start border-primary border-5">
                <h4 class="text-primary mb-4"><i class="fa-solid fa-chart-area me-2"></i>海岸線退縮監測數據</h4>
                <form method="POST" class="row g-3">
                    <div class="col-md-4"><input type="text" name="region_name" class="form-control" placeholder="地區(如: 台南黃金海岸)" required></div>
                    <div class="col-md-3"><input type="number" name="observation_year" class="form-control" placeholder="觀測年份" required></div>
                    <div class="col-md-3"><input type="number" step="0.1" name="retreat_distance" class="form-control" placeholder="退縮公尺數" required></div>
                    <div class="col-md-2"><button type="submit" name="add_retreat" class="btn btn-primary w-100">紀錄</button></div>
                </form>
            </div>
            <div class="card p-0 shadow-sm">
                <form method="POST">
                <div class="p-3 d-flex justify-content-between"><h5>觀測紀錄清單</h5><button name="delete_selected" class="btn btn-sm btn-outline-danger">刪除選中</button></div>
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark"><tr><th>#</th><th>地區</th><th>年份</th><th>退縮距離</th><th>風險判斷</th></tr></thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><input type="checkbox" name="delete_ids[]" value="<?= $row['id'] ?>"></td>
                            <td><?= $row['region_name'] ?></td>
                            <td><?= $row['observation_year'] ?></td>
                            <td><span class="text-danger fw-bold"><?= $row['retreat_distance'] ?> m</span></td>
                            <td><span class="badge <?= ($row['risk_level']=='極高危險')?'bg-danger':'bg-info' ?>"><?= $row['risk_level'] ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                </form>
            </div>

            <footer class="mt-4 pb-4 text-center text-muted small">
                © 2026 台灣水域環境平台專案 - 海綿寶寶與派大星開發
            </footer>

        </div>
    </div>
</div>
</body>
</html>